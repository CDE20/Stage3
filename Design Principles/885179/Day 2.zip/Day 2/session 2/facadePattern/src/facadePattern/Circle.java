package facadePattern;

public class Circle implements Shape{

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("circle draw");
	}
	

}
