package facadePattern;

public interface Shape {
  public void draw();
}
