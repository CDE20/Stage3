package chainOfResponsibility;

public class LeaveRequest {
	
 public String Employee;
 public int LeaveDays;
 LeaveRequest(String Employee,int LeaveDays)
 {
	 this.Employee=Employee;
	 this.LeaveDays=LeaveDays;
 }
}
