package adapterPattern;

public class BugattiVeyron implements Movable {
	@Override
	public double getSpeed()
	{ 
		return 268;
	}

	@Override
	public double getPrice() {
		// TODO Auto-generated method stub
		return 1900000;
	}
}
