package abstactFactoryHandson;

public class MercedesHeadlight extends Headlight {

}
