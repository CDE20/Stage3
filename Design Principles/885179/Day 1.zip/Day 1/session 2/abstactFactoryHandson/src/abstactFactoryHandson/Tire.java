package abstactFactoryHandson;

public abstract class Tire {
	void getTire() {
	System.out.println("tire");
	}
}
