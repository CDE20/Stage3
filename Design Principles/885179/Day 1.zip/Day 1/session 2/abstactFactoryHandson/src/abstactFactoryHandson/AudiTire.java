package abstactFactoryHandson;

public class AudiTire extends Tire{

}
