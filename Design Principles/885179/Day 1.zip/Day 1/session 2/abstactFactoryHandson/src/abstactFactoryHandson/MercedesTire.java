package abstactFactoryHandson;

public class MercedesTire extends Tire {

}
