package abstactFactoryHandson;

public class AudiHeadlight extends Headlight {

}
