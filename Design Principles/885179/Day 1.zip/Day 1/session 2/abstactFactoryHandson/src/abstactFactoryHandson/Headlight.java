package abstactFactoryHandson;

public abstract class  Headlight {
	void getHeadlight() {
		System.out.println("headlight");
		}
}
