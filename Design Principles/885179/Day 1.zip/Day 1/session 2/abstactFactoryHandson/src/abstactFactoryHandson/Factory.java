package abstactFactoryHandson;

public abstract class Factory {
	 public abstract Tire getBank(String tire);  
	  public abstract Headlight getLoan(String headlight);  
}
