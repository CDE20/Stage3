
public interface ProcessPhoneRepairInterface {
	 void ProcessPhoneRepair(String modelName);
}
