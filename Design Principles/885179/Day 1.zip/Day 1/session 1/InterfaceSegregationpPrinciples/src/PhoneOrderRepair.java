

public class PhoneOrderRepair implements ProcessOrderInterface {

	@Override
	public void ProcessOrder(String modelName) {
		// TODO Auto-generated method stub
		System.out.println("order accepted"+ modelName);
	}

  /*  @Override
	public void ProcessPhoneRepair(String modelName) {
		// TODO Auto-generated method stub
		System.out.println("repair accepted"+ modelName);
	}

	*/
	

}
