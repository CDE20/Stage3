

public class ProcessAccessoryRepairClass implements IOrderRepair {

	

	@Override
	public void ProcessAccessoryRepair(String accessoryType) {
		// TODO Auto-generated method stub
		System.out.println("repair accepted"+ accessoryType);
	}

}
