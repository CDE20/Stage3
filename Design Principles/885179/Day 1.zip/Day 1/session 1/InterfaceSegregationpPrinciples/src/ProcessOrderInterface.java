
public interface ProcessOrderInterface {
	 void ProcessOrder(String modelName);
}
