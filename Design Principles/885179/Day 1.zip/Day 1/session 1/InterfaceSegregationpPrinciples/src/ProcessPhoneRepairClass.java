

public class ProcessPhoneRepairClass implements ProcessPhoneRepairInterface{

	
	@Override
	public void ProcessPhoneRepair(String modelName) {
		// TODO Auto-generated method stub
		System.out.println("repair accepted"+ modelName);
	}

	

}
