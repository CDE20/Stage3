package com.cognizan.springlearn.service.exception;

public class CountryNotFoundException extends Exception{
	public CountryNotFoundException()
	{
		
	}

}
